// live_collector.vercel.js — push live data to your Vercel API
import WebSocket from 'ws';

const API_URL = process.env.API_URL || 'https://naiftradingbot.vercel.app/api/vip';
const API_KEY = process.env.API_KEY || 'change-me';

async function pushPrice(symbol, price, bid=null, ask=null, provider='binance') {
  const payload = { act:'push', key: API_KEY, symbol, price, bid, ask, provider, ts_ms: Date.now() };
  const r = await fetch(API_URL, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  const j = await r.json(); if(!r.ok || !j.ok) throw new Error('pushPrice failed: '+JSON.stringify(j)); console.log('Pushed', symbol, price);
}
async function pushCandle(symbol, tf, isoOpen, o,h,l,c,v=0) {
  const payload = { act:'push_candle', key: API_KEY, symbol, tf, ts_open: isoOpen, o, h, l, c, v };
  const r = await fetch(API_URL, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  const j = await r.json(); if(!r.ok || !j.ok) throw new Error('pushCandle failed: '+JSON.stringify(j)); console.log('Pushed candle', symbol, tf, isoOpen);
}

function startBinance(symbols=['BINANCE:BTCUSDT']) {
  const lower = symbols.map(s=> s.replace('BINANCE:','').toLowerCase());
  if (!lower.length) return;
  const streams = lower.flatMap(s=> [`${s}@bookTicker`, `${s}@kline_1m`]).join('/');
  const ws = new WebSocket(`wss://stream.binance.com:9443/stream?streams=${streams}`);
  ws.on('open', ()=> console.log('Binance connected'));
  ws.on('close', ()=> { console.log('Binance closed; reconnecting in 5s'); setTimeout(()=>startBinance(symbols), 5000); });
  ws.on('error', (e)=> console.error('WS error', e));
  ws.on('message', async (buf)=> {
    const n = JSON.parse(buf.toString()); const data = n.data || {}; const stream = n.stream||'';
    try {
      if (stream.endsWith('bookticker')) {
        const s = data.s; const bid = parseFloat(data.b); const ask = parseFloat(data.a);
        const price = Number.isFinite(ask)? ask : (Number.isFinite(bid)? bid : NaN); if (!Number.isFinite(price)) return;
        await pushPrice(`BINANCE:${s}`, price, bid, ask, 'binance');
      } else if (stream.includes('@kline_1m')) {
        const k = data.k; if (!k?.x) return;
        const iso = new Date(k.t).toISOString();
        await pushCandle(`BINANCE:${data.s}`, '1m', iso, parseFloat(k.o), parseFloat(k.h), parseFloat(k.l), parseFloat(k.c), parseFloat(k.q) || 0);
      }
    } catch(e){ console.error('handle error', e); }
  });
}
const list = (process.env.BINANCE_SYMBOLS || 'BINANCE:BTCUSDT').split(',').map(s=>s.trim()).filter(Boolean);
startBinance(list);
