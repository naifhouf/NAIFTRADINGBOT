// /api/vip.js — Vercel Serverless (Node.js) with Vercel KV
import { kv } from '@vercel/kv';

const API_KEY   = process.env.VIP_API_KEY || process.env.API_KEY || 'change-me';
const DEMO_MODE = (process.env.DEMO_MODE === '1' || process.env.DEMO_MODE === 'true') ? true : false;
const MAX_CANDLES = parseInt(process.env.MAX_CANDLES || '2000', 10);

function json(res, code, obj) {
  res.status(code).setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(obj));
}
function nowISO(ms) { const d = ms ? new Date(ms) : new Date(); return d.toISOString(); }
function normSymbol(s='') {
  const raw = (s||'').trim();
  let tv = raw.toUpperCase();
  if (!tv.includes(':') && !tv.includes('/')) {
    if (tv.length === 6) tv = 'FX:' + tv;
  }
  const api = tv.replace(/^FX:|^OANDA:|^BINANCE:/, '').replace('/','').replace(':','');
  return { tv, api };
}

export default async function handler(req, res) {
  try {
    const isGET = req.method === 'GET';
    const isPOST = req.method === 'POST';
    const q = isGET ? req.query : (typeof req.body === 'object' ? req.body : {});
    const act = (q.act || '').toLowerCase();

    if (act === 'price' && isGET) {
      const symbol = q.symbol || '';
      if (!symbol) return json(res, 400, { ok:false, error:'missing symbol' });
      const { tv, api } = normSymbol(symbol);
      const key = `price:${tv}`;
      let data = await kv.get(key);
      if (!data && DEMO_MODE) {
        const demo = { EURUSD:1.0865, GBPUSD:1.2740, USDJPY:151.25, XAUUSD:2415.50, BTCUSDT:61250 };
        const price = demo[api] ?? 1.0;
        return json(res, 200, { ok:true, price, bid:null, ask:null, source:'demo', updated_at: nowISO() });
      }
      if (!data) return json(res, 503, { ok:false, error:'no price available' });
      return json(res, 200, {
        ok: true, price: Number(data.price),
        bid: data.bid != null ? Number(data.bid) : null,
        ask: data.ask != null ? Number(data.ask) : null,
        updated_at: data.updated_at || nowISO(),
        tv_symbol: tv, api_symbol: data.api_symbol || api,
        source: data.source || 'kv'
      });
    }

    if (act === 'push' && isPOST) {
      const keyHdr = req.headers['authorization']?.replace(/^Bearer\s+/i,'') || q.key;
      if (keyHdr !== API_KEY) return json(res, 401, { ok:false, error:'unauthorized' });

      const symbol = q.symbol; const price  = q.price;
      const bid    = q.bid ?? null; const ask    = q.ask ?? null;
      const provider = q.provider || 'push'; const ts_ms  = q.ts_ms || Date.now();
      if (!symbol || !Number.isFinite(Number(price))) return json(res, 400, { ok:false, error:'invalid payload' });

      const { tv, api } = normSymbol(symbol);
      const doc = { price: Number(price), bid: bid != null ? Number(bid) : null, ask: ask != null ? Number(ask) : null,
                    updated_at: nowISO(ts_ms), tv_symbol: tv, api_symbol: api, source: provider };
      await kv.set(`price:${tv}`, doc);
      return json(res, 200, { ok:true, message:'price updated', tv_symbol: tv });
    }

    if (act === 'candles' && isGET) {
      const symbol = q.symbol || '';
      if (!symbol) return json(res, 400, { ok:false, error:'missing symbol' });
      const tf = String(q.tf || '1m').toLowerCase();
      const limit = Math.max(1, Math.min(parseInt(q.limit || '200',10), MAX_CANDLES));
      const { tv, api } = normSymbol(symbol);
      const rkey = `candles:${tv}:${tf}`;
      let rows = await kv.lrange(rkey, -limit, -1);
      if (!Array.isArray(rows)) rows = [];
      const parsed = rows.map(x => (typeof x === 'string' ? JSON.parse(x) : x)).filter(Boolean);
      parsed.sort((a,b)=> new Date(a.t) - new Date(b.t));
      return json(res, 200, { ok:true, symbol: api, tf, candles: parsed });
    }

    if (act === 'push_candle' && isPOST) {
      const keyHdr = req.headers['authorization']?.replace(/^Bearer\s+/i,'') || q.key;
      if (keyHdr !== API_KEY) return json(res, 401, { ok:false, error:'unauthorized' });

      const symbol = q.symbol; const tf = String(q.tf || '1m').toLowerCase(); const ts = q.ts_open;
      const o=q.o, h=q.h, l=q.l, c=q.c, v=q.v ?? 0;
      if (!symbol || !ts || ![o,h,l,c].every(x => Number.isFinite(Number(x)))) return json(res, 400, { ok:false, error:'invalid payload' });

      const { tv } = normSymbol(symbol);
      const rkey = `candles:${tv}:${tf}`;
      const row = { t: ts, o: Number(o), h: Number(h), l: Number(l), c: Number(c), v: Number(v) };
      await kv.lpush(rkey, JSON.stringify(row));
      await kv.ltrim(rkey, 0, MAX_CANDLES - 1);
      return json(res, 200, { ok:true, message:'candle upserted' });
    }

    return json(res, 400, { ok:false, error:'unknown act' });
  } catch (e) {
    return json(res, 500, { ok:false, error:'server error', detail: String(e?.message || e) });
  }
}
