# مشروع جاهز لـ Vercel (بدون PHP)

## ماذا يحتوي؟
- `api/vip.js` : دالة سيرفرلس تخزن السعر والشموع في Vercel KV.
- `index.html` : واجهة بسيطة تقرأ من `/api/vip`.
- `live_collector.vercel.js` : جامع Binance يدفع للـAPI.
- `vercel.json` : يضمن تشغيل Node 20 لواجهة الـAPI.
- `package.json` : لإضافة @vercel/kv.
- `.env.example` : قالب متغيرات البيئة.

## خطوات النشر
1) ارفع هذا المجلد إلى مشروعك على Vercel (Git أو Upload).
2) فعّل تكامل **Vercel KV** من لوحة Integrations لمشروعك.
3) أضف متغير بيئة:
   - `VIP_API_KEY` (قيمة قوية)
   - `DEMO_MODE` = `1` للتجربة (اختياري)
4) انشر. اختبر:
   - `/api/vip?act=price&symbol=BINANCE:BTCUSDT`
5) لتغذية البيانات الحية، شغّل الجامع محلياً:
   ```bash
   npm i ws
   export API_URL="https://YOUR-PROJECT.vercel.app/api/vip"
   export API_KEY="<نفس VIP_API_KEY>"
   export BINANCE_SYMBOLS="BINANCE:BTCUSDT"
   node live_collector.vercel.js
   ```
